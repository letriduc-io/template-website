# Unicons

1000+ Pixel-perfect vector icons and Iconfont for your next project.
